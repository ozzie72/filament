<div <?php echo e($attributes->class('flex-1')); ?> data-flux-spacer></div>
<?php /**PATH C:\laragon\www\filament\vendor\livewire\flux\stubs\resources\views\flux\spacer.blade.php ENDPATH**/ ?>